import os
from datetime import datetime

# Specify your folder path containing the .png files
folder_path = os.getcwd() + "/I465Maps"

# List all files in the folder
files = os.listdir(folder_path)

# Create a dictionary to map day names to folder names
day_to_folder = {
    0: "Monday",
    1: "Tuesday",
    2: "Wednesday",
    3: "Thursday",
    4: "Friday",
    5: "Saturday",
    6: "Sunday"
}

# Iterate through each file
for filename in files:
    if filename.lower().endswith(".png"):
        # Extract the date portion from the file name
        date_str = filename.split("_")[1].split(".")[0]  # Assuming the format is "CarCrashHeatmap_yyyy-mm-dd.png"

        # Convert the date string to a datetime object
        try:
            file_date = datetime.strptime(date_str, "%Y-%m-%d")
        except ValueError:
            print(f"Skipping invalid file name: {filename}")
            continue

        # Get the day of the week (0 = Monday, 6 = Sunday)
        day_of_week = file_date.weekday()

        # Create the day-of-the-week folder if it doesn't exist
        folder_name = day_to_folder.get(day_of_week, "Other")
        folder_path_for_file = os.path.join(folder_path, folder_name)
        os.makedirs(folder_path_for_file, exist_ok=True)

        # Move the file to the appropriate folder
        source_file_path = os.path.join(folder_path, filename)
        target_file_path = os.path.join(folder_path_for_file, filename)
        os.rename(source_file_path, target_file_path)
        print(f"Moved {filename} to {folder_name} folder.")

print("Files organized successfully!")