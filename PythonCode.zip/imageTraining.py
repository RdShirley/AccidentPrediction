import numpy as np
import tensorflow as tf
from keras.layers import Conv2D, Dense, Flatten
from keras.models import Sequential

import os
import pandas as pd
from skimage import io
from sklearn.model_selection import train_test_split
# Define the root directory where subfolders with heatmaps are located
root_directory = "C:/Users/richa/Documents/TrafficDirectedProject/I456Maps"

# Initialize an empty DataFrame to store heatmap data
heatmap_df = pd.DataFrame(columns=["Category", "Heatmap_Path"])

# Recursively search for heatmap files
for dirpath, dirnames, filenames in os.walk(root_directory):
    for filename in filenames:
        if filename.endswith(".png"):  # Adjust the file extension as needed
            heatmap_path = os.path.join(dirpath, filename)
            category = os.path.basename(dirpath)  # Use subfolder name as category
            heatmap_df = heatmap_df._append({"Category": category, "Heatmap_Path": heatmap_path}, ignore_index=True)#

# Display the loaded data
#print(heatmap_df.head())

x_train = []
y_train = []

# Load heatmap images and labels
for index, row in heatmap_df.iterrows():
    heatmap_path = row["Heatmap_Path"]
    category = row["Category"]

    # Load and preprocess the heatmap image (resize, normalize, etc.)
    heatmap_image = io.imread(heatmap_path)
    # Add any necessary preprocessing steps here

    # Append to x_train and y_train
    x_train.append(heatmap_image)
    y_train.append(category)

# Convert lists to numpy arrays
x_train = np.array(x_train)
y_train = np.array(y_train)

X_train, X_test, Y_train, Y_test = train_test_split(x_train, y_train, test_size=0.2, random_state=42)
# Split the original training data into training and validation sets
X_train, X_val, Y_train, Y_val = train_test_split(X_train, Y_train, test_size=0.1, random_state=42)

# Define your neural network architecture
image_height = 600;
image_width = 1000;
output_size = (600,1000);

model = Sequential()
model.add(Conv2D(64, kernel_size=(3, 3), activation='relu', input_shape=(image_height, image_width, 8)))
model.add(Conv2D(32, kernel_size=(3, 3), activation='relu'))
model.add(Flatten())
model.add(Dense(output_size))  # Output size should match heatmap dimensions

# Compile the model
model.compile(optimizer='adam', loss='mean_squared_error')

# Train the model
model.fit(x_train, y_train, epochs=5, validation_data=(X_val, Y_val))

# Evaluate the model
loss = model.evaluate(X_test, Y_test)
print(f"Test loss: {loss}")

# Generate heatmaps for new images
predicted_heatmaps = model.predict(new_images)

# Visualize the results and compare with ground truth
# (You can use matplotlib or other visualization libraries)









# import os
# import torch
# import torch.nn as nn
# import torch.optim as optim
# from torchvision import transforms, datasets
# from torchvision.models import resnet18
#
# # Set your heatmap folder path
# heatmap_folder = os.getcwd() + "\\I456Maps"
#
#
# # Define data transformations
# data_transforms = transforms.Compose([
#     transforms.Resize((224, 224)),
#     transforms.ToTensor(),
#     transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
# ])
#
# # Load heatmaps
# heatmap_dataset = datasets.ImageFolder(root=heatmap_folder, transform=data_transforms)
#
# # Create data loader
# batch_size = 32
# heatmap_loader = torch.utils.data.DataLoader(heatmap_dataset, batch_size=batch_size, shuffle=True)
#
# # Load pre-trained ResNet18 model
# model = resnet18(pretrained=True)
# num_classes = len(heatmap_dataset.classes)
#
# # Modify the classifier for transfer learning
# model.fc = nn.Sequential(
#     nn.Linear(model.fc.in_features, 512),
#     nn.ReLU(),
#     nn.Dropout(0.5),
#     nn.Linear(512, num_classes)
# )
#
# # Define loss function and optimizer
# criterion = nn.CrossEntropyLoss()
# optimizer = optim.Adam(model.parameters(), lr=0.001)
#
# # Train the model
# num_epochs = 10
# device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# model.to(device)
#
# for epoch in range(num_epochs):
#     model.train()
#     for inputs, labels in heatmap_loader:
#         inputs, labels = inputs.to(device), labels.to(device)
#         optimizer.zero_grad()
#         outputs = model(inputs)
#         loss = criterion(outputs, labels)
#         loss.backward()
#         optimizer.step()
#
# # Save the trained model
# torch.save(model.state_dict(), "heatmap_recognition_model.pth")