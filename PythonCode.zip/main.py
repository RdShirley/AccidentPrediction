#Richard Shirley
#Directed Project: Predicting Traffic Accidents
import calendar
import datetime
#Step 1, sorting through the json files to collect only the data that is relavent to crashes.
import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime

# Load your data (assuming it's in JSON format)
df = pd.read_json("C:/Users/richa/Documents/TrafficDirectedProject/CrashData")

# Extract the hour and the location from the dataframe
datetimes = [datetime.fromtimestamp(ts / 1000) for ts in df['dateStart']]
df['datetime'] = datetimes

# Extract hour and calendar day
df['hour'] = df['datetime'].dt.hour
df['calendar_day'] = df['datetime'].dt.date

# Restrict to route I-465
df = df[df['route'] == 'I-465']

# Group by calendar day, hour, and route
df['mile_bin'] = pd.cut(df['startMileMarker'], bins=range(0, 100, 5))

# Ensure there are enough data points for each route
df = df[df.groupby('route')['route'].transform('count') >= 100]

# Create separate heatmaps for each calendar day
grouped = df.groupby(['calendar_day', 'hour', 'mile_bin'])['startMileMarker'].count().reset_index()

# Pivot the data for individual heatmaps
pivot_tables = {}
for day in df["calendar_day"].unique():
    day_df = df[df["calendar_day"] == day]
    pivot_table = day_df.pivot_table(index="hour", columns="mile_bin", values="startMileMarker", aggfunc="count")
    # Replace zeros with NaN
    pivot_table[pivot_table == 0] = np.nan
    pivot_tables[day] = pivot_table

# Plot the heatmap for each calendar day
all_counts = [table.to_numpy().flatten() for table in pivot_tables.values()]
global_min = pd.Series(np.concatenate(all_counts)).min()
global_max = pd.Series(np.concatenate(all_counts)).max()

if not os.path.exists("I465Maps"):
    os.makedirs("I465Maps")

# Plot the heatmap for each calendar day
# for day, pivot_table in pivot_tables.items():
#     # Reindex the pivot_table to include all hours
#     all_hours = pd.Index(range(24), name="hour")
#     pivot_table = pivot_table.reindex(all_hours)
#
#     plt.figure(figsize=(10, 6))
#     sns.heatmap(pivot_table, annot=True, cmap="coolwarm", fmt=".0f", vmin=global_min, vmax=global_max)
#     plt.title(f"Car Crash Heatmap (I-465, {day})")
#     plt.xlabel("Mile Marker (Bins of 5 miles)")
#     plt.ylabel("Hour")
#     plt.xticks(rotation=90)
#     plt.tight_layout()
#     #plt.show()
#     plt.savefig(f"I465Maps/CarCrashHeatmap_{day}.png") # save the heatmap as an image
#     plt.close()
################################################################


df["location"] = df["locationDetails"].apply(lambda x: x["district"][0])

route_counts = df.groupby('route').size()

# Filter out routes with less than 100 entries
valid_routes = route_counts[route_counts >= 100].index

# Create a new data frame with only valid routes
filtered_df = df[df['route'].isin(valid_routes)]
#
# ####Code which shows a list of crash counts by route binned into every 10 mile markers.
# grouped_df = filtered_df.groupby(["route", pd.cut(filtered_df["startMileMarker"], bins=range(0, 100, 10))]).size().reset_index(name="count")
# grouped_df = grouped_df[grouped_df["count"] > 0]
#
# print(grouped_df)



### Code to get the number of records per route
# route_counts = df.groupby('route').size()
#
# # Print the result
# print(route_counts)



#####Code that displays different charts
# df["location"] = df["route"] #+ "-" + df["startMileMarker"].astype(str)
#
# # Group the dataframe by hour and location and count the number of crashes
# df_grouped = df.groupby(["hour", "location"])["id"].count().reset_index()
#
# #Pivot the dataframe to create a matrix of hour and location
# df_pivoted = df_grouped.pivot(index="location", columns="hour", values="id")
# #Create a heatmap using seaborn
# sns.heatmap(df_pivoted, cmap="Blues")
# plt.xlabel("Hour")
# plt.ylabel("Location")
# plt.title("Heatmap of crash data")
# plt.show()
#

# #### Result of a Heatmap shows that there are more crashes on specific highways during specific hours of the day
# #### Some highways, like IN 62 barely have any crashes at all, though.
# #### As such, I would recommend limiting data to crashes which occur on routes that have notable data.
# #### Requesting more data to bolster associations would be helpful.
#


# # Plot the scatter plot using plt.scatter()
# df_hourly = df.groupby(df["hour"])["id"].count()
# plt.scatter(df_hourly.index, df_hourly.values)
# plt.xlabel("Hour of the day")
# plt.ylabel("Observed crashes")
# plt.show()
###### Result of a Scatterplot is a non-linear relationship. ####











