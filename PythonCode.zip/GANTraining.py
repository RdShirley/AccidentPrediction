import os

import numpy as np
from keras.layers import Dense, Reshape, LeakyReLU, Dropout, ZeroPadding2D, Conv2DTranspose
from keras.models import Sequential
from keras.optimizers import Adam
from keras.src.layers import Conv2D, Flatten, BatchNormalization
from keras.src.legacy.preprocessing.image import ImageDataGenerator
from keras.src.utils import load_img, img_to_array
from sklearn.preprocessing import LabelEncoder
from keras import Input, Model

#from tensorflow.python.keras import Input

# Define the generator model
def build_generator(z_dim):
    model = Sequential()

    model.add(Dense(256, input_shape=z_dim))
    model.add(LeakyReLU(alpha=0.2))
    model.add(BatchNormalization(momentum=0.8))
    model.add(Dense(512))
    model.add(LeakyReLU(alpha=0.2))
    model.add(BatchNormalization(momentum=0.8))
    model.add(Dense(1024))
    model.add(LeakyReLU(alpha=0.2))
    model.add(BatchNormalization(momentum=0.8))

    model.add(Dense(np.prod(img_shape),activation='tanh'))
    model.add(Reshape(img_shape))

    model.summary()

    noise = Input(shape=z_dim)
    img = model(noise)
    return model

    # model.add(Input(shape=(z_dim)))
    # model.add(Dense(256 * 75 * 125, input_dim=z_dim))
    # model.add(Reshape((75, 125, 256)))
    # model.add(Conv2DTranspose(128, kernel_size=3, strides=2, padding='same', activation='relu'))
    # model.add(Conv2DTranspose(64, kernel_size=3, strides=2, padding='same', activation='relu'))
    # model.add(Conv2DTranspose(1, kernel_size=3, strides=2, padding='same', activation='tanh'))

# Define the discriminator model
def build_discriminator(img_shape):
    model = Sequential()

    model.add(Flatten(input_shape=img_shape))
    model.add(Dense(512))
    model.add(LeakyReLU(alpha=0.2))
    model.add(Dense(256))
    model.add(LeakyReLU(alpha=0.2))

    model.add(Dense(1,activation='sigmoid'))
    model.summary()
    img = Input(shape=img_shape)
    validity = model(img)

    return model
    # # First Conv2D layer with input shape specified and LeakyReLU activation
    # model.add(Conv2D(64, kernel_size=3, strides=2, input_shape=img_shape, padding='same'))
    # model.add(LeakyReLU(alpha=0.2))
    # model.add(Dropout(0.25))
    # # Second Conv2D layer with LeakyReLU activation
    # model.add(Conv2D(128, kernel_size=3, strides=2, padding='same'))
    # model.add(LeakyReLU(alpha=0.2))
    # model.add(Dropout(0.25))
    #
    # # Flatten and Dense for the output
    # model.add(Flatten())
    # model.add(Dense(1, activation='sigmoid'))


# Define the GAN model
def build_gan(generator, discriminator):
    # Input for the generator
    z_dim = generator.input_shape[1]
    gan_input = Input(shape=(z_dim,))

    # Generate images from the input
    generated_images = generator(gan_input)

    # Discriminator determines validity
    discriminator.trainable = False  # Only train the generator
    gan_output = discriminator(generated_images)

    # Define the GAN model
    model = Model(gan_input, gan_output)

    return model
# Model hyperparameters
z_dim = (100,)  # Size of the noise vector
img_shape = (600, 1000, 1)  # Input image dimensions

# Build and compile the discriminator
discriminator = build_discriminator(img_shape)
discriminator.compile(loss='binary_crossentropy', optimizer=Adam(), metrics=['accuracy'])

# Build the generator
generator = build_generator(z_dim)

# Keep the discriminator's parameters constant for the generator training
discriminator.trainable = False

# Build and compile the GAN model with both generator and discriminator
gan = build_gan(generator, discriminator)
gan.compile(loss='binary_crossentropy', optimizer=Adam())

#Training loop

epochs = 10000
batch_size = 132 #used to be 32
save_interval = 50
z_dim = 100  # Size of the noise vector
num_categories = 7  # Number of categories for which you have data

# Prepare your real heatmap data (assuming it's already loaded and preprocessed)

def load_heatmaps_and_categories(base_path, img_shape):
    real_images = []
    parameters = []
    categories = os.listdir(base_path)  # Assuming each category has its own subdirectory

    for category in categories:
        category_path = os.path.join(base_path, category)
        images = os.listdir(category_path)

        for image_name in images:
            image_path = os.path.join(category_path, image_name)
            image = load_img(image_path, color_mode='grayscale', target_size=img_shape[:2])
            image = img_to_array(image)
            image /= 255.0  # Normalize the image

            real_images.append(image)
            parameters.append(category)  # You might want to map this to a numerical value

    return np.array(real_images), np.array(parameters)


# Usage
base_path = 'C:/Users/richa/Documents/TrafficDirectedProject/I456Maps'  # Replace with the path to your heatmap directories
real_heatmaps, categories = load_heatmaps_and_categories(base_path, img_shape)


#real_heatmaps = ...  # Your preprocessed heatmap data
#categories = ...  # Corresponding categories for each heatmap

# Convert category labels to one-hot encoded vectors
from keras.utils import to_categorical

# Assuming 'categories' is your list of day names (e.g., ['Monday', 'Tuesday', ...])
day_mapping = {
    'Friday': 0,
    'Saturday': 1,
    'Sunday': 2,
    'Monday': 3,
    'Tuesday': 4,
    'Wednesday': 5,
    'Thursday': 6
}
# Convert the day names to integers
categories = [day_mapping.get(entry, entry) for entry in categories]

category_labels = to_categorical(categories, num_categories)

label_encoder = LabelEncoder()
category_indices = label_encoder.fit_transform(categories)

# Now you can convert to one-hot encoded vectors
category_labels = to_categorical(category_indices, num_categories)

# Create a data generator for the real heatmaps
data_gen = ImageDataGenerator()
data_gen.fit(real_heatmaps)

for epoch in range(epochs):
    for _ in range(batch_size):
        # Train the discriminator
        # Generate fake heatmaps
        noise = np.random.normal(0, 1, size=(batch_size, z_dim))#batch_size, z_dim
        fake_heatmaps = generator.predict(x=noise) #[noise, category_labels]
        # Get a random batch of real heatmaps
        real_batch = next(data_gen.flow(real_heatmaps, batch_size=batch_size))
        # Labels for real and fake data
        real_labels = np.ones((batch_size, 1))
        fake_labels = np.zeros((batch_size, 1))
        # Train the discriminator
        d_loss_real = discriminator.train_on_batch(real_batch, real_labels)
        d_loss_fake = discriminator.train_on_batch(fake_heatmaps, fake_labels)
        d_loss = 0.5 * np.add(d_loss_real, d_loss_fake)
        # Train the generator
        noise = np.random.normal(0, 1, (batch_size, z_dim))
        # The generator wants the discriminator to label the fake heatmaps as real
        valid_y = np.ones((batch_size, 1))
        # Train the generator
        g_loss = gan.train_on_batch(x={'input_layer_4': noise, 'input_layer_5': category_labels}, y=valid_y)

    print(f"Epoch: {epoch}, Discriminator Loss: {d_loss}, Generator Loss: {g_loss}")

generator.save("ganSave.h5")

# # Generate images from random noise
# noise = np.random.normal(0, 1, size=(32, z_dim))
# generated_images = generator.predict(noise)
